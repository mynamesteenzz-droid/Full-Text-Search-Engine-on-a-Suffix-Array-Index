package FullTextSearchEngine;

public class SuffixArray {

    private String text;
    private int[] suffixArray;

    public SuffixArray(String text) {
        this.text = text;

        // Construct the suffix array using
        // the doubling technique.
        suffixArray = buildSuffixArray(text);
    }

    /*
     * Builds the suffix array using the
     * prefix-doubling method.
     *
     * At every step we sort suffixes according
     * to the first 2, 4, 8, 16... characters.
     *
     * Merge sort takes O(n log n) per round.
     * There are O(log n) rounds.
     *
     * Therefore the practical complexity is:
     * O(n log^2 n)
     */
    private int[] buildSuffixArray(String text) {

        int n = text.length();

        int[] sa = new int[n];
        int[] rank = new int[n];
        int[] newRank = new int[n];

        // Initially every suffix starts at one
        // position in the original text.
        for (int i = 0; i < n; i++) {

            sa[i] = i;

            // Initial rank is based on the character.
            rank[i] = text.charAt(i);
        }

        // Double the number of characters considered
        // in every iteration.
        for (int length = 1;
             length < n;
             length *= 2) {

            // Sort suffix positions according to
            // their current ranks.
            mergeSort(
                    sa,
                    rank,
                    length,
                    0,
                    n - 1
            );

            // Assign new ranks after sorting.
            newRank[sa[0]] = 0;

            for (int i = 1; i < n; i++) {

                int previous =
                        sa[i - 1];

                int current =
                        sa[i];

                if (compareSuffixes(
                        previous,
                        current,
                        length,
                        rank,
                        n
                ) < 0) {

                    newRank[current] =
                            newRank[previous] + 1;

                } else {

                    newRank[current] =
                            newRank[previous];
                }
            }

            // Copy new ranks back.
            for (int i = 0; i < n; i++) {
                rank[i] = newRank[i];
            }

            // If every suffix has a unique rank,
            // the suffix array is complete.
            if (rank[sa[n - 1]] == n - 1) {
                break;
            }
        }

        return sa;
    }

    /*
     * Compares two suffixes using their current
     * rank and the rank of the next block.
     */
    private int compareSuffixes(
            int first,
            int second,
            int length,
            int[] rank,
            int n) {

        if (rank[first] != rank[second]) {

            return rank[first] - rank[second];
        }

        int firstNext =
                first + length < n
                        ? rank[first + length]
                        : -1;

        int secondNext =
                second + length < n
                        ? rank[second + length]
                        : -1;

        return firstNext - secondNext;
    }

    /*
     * Merge sort is implemented manually.
     *
     * This avoids using Java's built-in sorting
     * algorithms and follows the course requirement
     * that algorithms should be hand-built.
     */
    private void mergeSort(
            int[] sa,
            int[] rank,
            int length,
            int left,
            int right) {

        if (left >= right) {
            return;
        }

        int middle =
                left + (right - left) / 2;

        mergeSort(
                sa,
                rank,
                length,
                left,
                middle
        );

        mergeSort(
                sa,
                rank,
                length,
                middle + 1,
                right
        );

        merge(
                sa,
                rank,
                length,
                left,
                middle,
                right
        );
    }

    /*
     * Merges two sorted parts of the suffix array.
     */
    private void merge(
            int[] sa,
            int[] rank,
            int length,
            int left,
            int middle,
            int right) {

        int size =
                right - left + 1;

        int[] temp =
                new int[size];

        int i = left;
        int j = middle + 1;
        int k = 0;

        while (
                i <= middle &&
                j <= right
        ) {

            if (
                    compareSuffixes(
                            sa[i],
                            sa[j],
                            length,
                            rank,
                            text.length()
                    ) <= 0
            ) {

                temp[k++] = sa[i++];

            } else {

                temp[k++] = sa[j++];
            }
        }

        while (i <= middle) {
            temp[k++] = sa[i++];
        }

        while (j <= right) {
            temp[k++] = sa[j++];
        }

        for (int x = 0; x < size; x++) {
            sa[left + x] = temp[x];
        }
    }

    public int[] getSuffixArray() {
        return suffixArray;
    }

    public String getText() {
        return text;
    }
}