package FullTextSearchEngine;

public class LCPArray {

    private String text;
    private int[] suffixArray;
    private int[] lcp;

    public LCPArray(
            String text,
            int[] suffixArray) {

        this.text = text;
        this.suffixArray = suffixArray;

        // Build LCP using Kasai's algorithm.
        buildLCP();
    }

    /*
     * Kasai's algorithm calculates the Longest
     * Common Prefix between neighbouring suffixes.
     *
     * Time complexity: O(n)
     */
    private void buildLCP() {

        int n = text.length();

        lcp = new int[n];

        // rank[i] tells us the position of the
        // suffix starting at i inside the suffix array.
        int[] rank = new int[n];

        for (int i = 0; i < n; i++) {

            rank[suffixArray[i]] = i;
        }

        int k = 0;

        for (int i = 0; i < n; i++) {

            // Last suffix has no next suffix.
            if (rank[i] == n - 1) {

                k = 0;
                continue;
            }

            // Get the next suffix.
            int j =
                    suffixArray[
                            rank[i] + 1
                    ];

            // Compare characters until they differ.
            while (
                    i + k < n &&
                    j + k < n &&
                    text.charAt(i + k)
                    ==
                    text.charAt(j + k)
            ) {

                k++;
            }

            lcp[rank[i]] = k;

            // Kasai optimization:
            // next comparison can reuse k - 1.
            if (k > 0) {
                k--;
            }
        }
    }

    public int[] getLCP() {
        return lcp;
    }
}