package FullTextSearchEngine;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.File;
import java.nio.file.Files;

public class Main {

    private JFrame frame;

    private JTextArea documentArea;
    private JTextField searchField;
    private JTextArea resultArea;

    // Dropdown for selecting the type of query.
    private JComboBox<String> searchType;

    // Stores all uploaded documents.
    private Documents[] documents =
            new Documents[0];

    // DSA components.
    private SuffixArray suffixArray;
    private LCPArray lcpArray;
    private SearchEngine searchEngine;

    // Combined text used for building the index.
    private String combinedText = "";

    public Main() {

        frame =
                new JFrame(
                        "Full-Text Search Engine"
                );

        frame.setSize(1000, 650);

        frame.setDefaultCloseOperation(
                JFrame.EXIT_ON_CLOSE
        );

        frame.setLocationRelativeTo(null);

        JPanel mainPanel =
                new JPanel(
                        new BorderLayout(10, 10)
                );

        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        15, 15, 15, 15
                )
        );

        // -------------------------------------------------
        // TITLE
        // -------------------------------------------------

        JLabel title =
                new JLabel(
                        "FULL-TEXT SEARCH ENGINE",
                        SwingConstants.CENTER
                );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        26
                )
        );

        mainPanel.add(
                title,
                BorderLayout.NORTH
        );

        // -------------------------------------------------
        // DOCUMENT PANEL
        // -------------------------------------------------

        JPanel documentPanel =
                new JPanel(
                        new BorderLayout(5, 5)
                );

        JLabel documentLabel =
                new JLabel(
                        "DOCUMENTS"
                );

        documentLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        16
                )
        );

        documentArea =
                new JTextArea();

        documentArea.setEditable(false);

        documentArea.setText(
                "No documents uploaded yet."
        );

        JScrollPane documentScroll =
                new JScrollPane(
                        documentArea
                );

        JButton uploadButton =
                new JButton(
                        "Upload Documents"
                );

        JButton buildButton =
                new JButton(
                        "Build Index"
                );

        JPanel documentButtons =
                new JPanel(
                        new GridLayout(
                                2,
                                1,
                                5,
                                5
                        )
                );

        documentButtons.add(
                uploadButton
        );

        documentButtons.add(
                buildButton
        );

        documentPanel.add(
                documentLabel,
                BorderLayout.NORTH
        );

        documentPanel.add(
                documentScroll,
                BorderLayout.CENTER
        );

        documentPanel.add(
                documentButtons,
                BorderLayout.SOUTH
        );

        // -------------------------------------------------
        // SEARCH PANEL
        // -------------------------------------------------

        JPanel searchPanel =
                new JPanel(
                        new BorderLayout(5, 5)
                );

        JLabel searchLabel =
                new JLabel(
                        "SEARCH"
                );

        searchLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        16
                )
        );

        searchField =
                new JTextField();

        searchType =
                new JComboBox<>(
                        new String[]{
                                "Substring",
                                "Prefix",
                                "Exact Phrase"
                        }
                );

        JButton searchButton =
                new JButton(
                        "Search"
                );

        JButton clearButton =
                new JButton(
                        "Clear"
                );

        JPanel searchOptions =
                new JPanel(
                        new GridLayout(
                                1,
                                3,
                                5,
                                5
                        )
                );

        searchOptions.add(
                searchType
        );

        searchOptions.add(
                searchButton
        );

        searchOptions.add(
                clearButton
        );

        searchPanel.add(
                searchLabel,
                BorderLayout.NORTH
        );

        searchPanel.add(
                searchField,
                BorderLayout.CENTER
        );

        searchPanel.add(
                searchOptions,
                BorderLayout.EAST
        );

        // -------------------------------------------------
        // RESULTS
        // -------------------------------------------------

        JPanel resultPanel =
                new JPanel(
                        new BorderLayout(5, 5)
                );

        JLabel resultLabel =
                new JLabel(
                        "SEARCH RESULTS"
                );

        resultLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        16
                )
        );

        resultArea =
                new JTextArea();

        resultArea.setEditable(false);

        resultArea.setFont(
                new Font(
                        "Monospaced",
                        Font.PLAIN,
                        13
                )
        );

        resultArea.setText(
                "Search results will appear here."
        );

        JScrollPane resultScroll =
                new JScrollPane(
                        resultArea
                );

        resultPanel.add(
                resultLabel,
                BorderLayout.NORTH
        );

        resultPanel.add(
                resultScroll,
                BorderLayout.CENTER
        );

        // -------------------------------------------------
        // CENTER PANEL
        // -------------------------------------------------

        JPanel centerPanel =
                new JPanel(
                        new BorderLayout(10, 10)
                );

        centerPanel.add(
                searchPanel,
                BorderLayout.NORTH
        );

        centerPanel.add(
                resultPanel,
                BorderLayout.CENTER
        );

        mainPanel.add(
                documentPanel,
                BorderLayout.WEST
        );

        mainPanel.add(
                centerPanel,
                BorderLayout.CENTER
        );

        frame.add(mainPanel);

        // -------------------------------------------------
        // BUTTON ACTIONS
        // -------------------------------------------------

        uploadButton.addActionListener(
                e -> uploadDocuments()
        );

        buildButton.addActionListener(
                e -> buildIndex()
        );

        searchButton.addActionListener(
                e -> performSearch()
        );

        clearButton.addActionListener(
                e -> searchField.setText("")
        );
    }

    /*
     * Opens a file chooser and allows the user
     * to upload multiple TXT documents.
     */
    private void uploadDocuments() {

        JFileChooser chooser =
                new JFileChooser();

        chooser.setMultiSelectionEnabled(
                true
        );

        chooser.setFileSelectionMode(
                JFileChooser.FILES_ONLY
        );

        FileNameExtensionFilter filter =
                new FileNameExtensionFilter(
                        "Text Files (*.txt)",
                        "txt"
                );

        chooser.setFileFilter(filter);

        int result =
                chooser.showOpenDialog(frame);

        if (
                result !=
                JFileChooser.APPROVE_OPTION
        ) {

            return;
        }

        File[] selectedFiles =
                chooser.getSelectedFiles();

        Documents[] newDocuments =
                new Documents[
                        documents.length
                        + selectedFiles.length
                ];

        // Preserve previously uploaded documents.
        for (
                int i = 0;
                i < documents.length;
                i++
        ) {

            newDocuments[i] =
                    documents[i];
        }

        int position =
                documents.length;

        // Read every selected text file.
        for (
                int i = 0;
                i < selectedFiles.length;
                i++
        ) {

            try {

                String content =
                        Files.readString(
                                selectedFiles[i]
                                        .toPath()
                        );

                newDocuments[position] =
                        new Documents(
                                selectedFiles[i]
                                        .getName(),
                                content
                        );

                position++;

            } catch (Exception ex) {

                JOptionPane.showMessageDialog(
                        frame,
                        "Could not read file:\n"
                        + selectedFiles[i]
                                .getName()
                );
            }
        }

        documents =
                newDocuments;

        // Display uploaded documents.
        documentArea.setText(
                "UPLOADED DOCUMENTS\n\n"
        );

        for (
                int i = 0;
                i < documents.length;
                i++
        ) {

            documentArea.append(
                    (i + 1)
                    + ". "
                    + documents[i].getName()
                    + "\n"
            );
        }

        documentArea.append(
                "\nTotal Documents: "
                + documents.length
        );
    }

    /*
     * Combines all uploaded documents and builds
     * the two main DSA structures:
     *
     * 1. Suffix Array
     * 2. LCP Array
     */
    private void buildIndex() {

        if (documents.length == 0) {

            JOptionPane.showMessageDialog(
                    frame,
                    "Please upload documents first."
            );

            return;
        }

        StringBuilder builder =
                new StringBuilder();

        for (
                int i = 0;
                i < documents.length;
                i++
        ) {

            builder.append(
                    documents[i].getContent()
            );

            // Separator between documents.
            builder.append(" ");
        }

        combinedText =
                builder.toString();

        resultArea.setText(
                "BUILDING INDEX...\n\n"
        );

        // Step 1: Build suffix array.
        suffixArray =
                new SuffixArray(
                        combinedText
                );

        // Step 2: Build LCP array using Kasai.
        lcpArray =
                new LCPArray(
                        combinedText,
                        suffixArray.getSuffixArray()
                );

        // Step 3: Create the search engine.
        searchEngine =
                new SearchEngine(
                        combinedText,
                        suffixArray.getSuffixArray(),
                        lcpArray.getLCP()
                );

        resultArea.append(
                "INDEX CREATED SUCCESSFULLY\n\n"
                + "Documents       : "
                + documents.length
                + "\n"
                + "Text length     : "
                + combinedText.length()
                + "\n"
                + "Suffix Array    : Created\n"
                + "LCP Array       : Created using Kasai\n"
                + "Search Engine   : Ready\n\n"
                + "You can now search the documents."
        );
    }

    /*
     * Performs the search and ranks documents
     * according to the number of matches.
     */
    private void performSearch() {

        String query =
                searchField
                        .getText()
                        .trim();

        if (query.length() == 0) {

            JOptionPane.showMessageDialog(
                    frame,
                    "Please enter a search query."
            );

            return;
        }

        if (searchEngine == null) {

            JOptionPane.showMessageDialog(
                    frame,
                    "Please build the index first."
            );

            return;
        }

        String type =
                (String)
                searchType.getSelectedItem();

        // Prefix search checks whether the query
        // appears at the beginning of a document.
        if (
                "Prefix".equals(type)
        ) {

            performPrefixSearch(query);
            return;
        }

        // Exact phrase and substring searches
        // both use the suffix-array search.
        int[] positions =
                searchEngine.search(query);

        if (positions.length == 0) {

            resultArea.setText(
                    "SEARCH RESULTS\n\n"
                    + "Query: "
                    + query
                    + "\n"
                    + "Type: "
                    + type
                    + "\n\n"
                    + "No matching text found."
            );

            return;
        }

        // Count occurrences in every document.
        int[] matchCount =
                new int[documents.length];

        for (
                int i = 0;
                i < documents.length;
                i++
        ) {

            matchCount[i] =
                    searchEngine.countMatches(
                            documents[i]
                                    .getContent(),
                            query
                    );
        }

        // Store document indexes.
        int[] order =
                new int[documents.length];

        for (
                int i = 0;
                i < order.length;
                i++
        ) {

            order[i] = i;
        }

        // Sort documents according to match count.
        for (
                int i = 0;
                i < order.length - 1;
                i++
        ) {

            for (
                    int j = i + 1;
                    j < order.length;
                    j++
            ) {

                if (
                        matchCount[order[j]]
                        >
                        matchCount[order[i]]
                ) {

                    int temp =
                            order[i];

                    order[i] =
                            order[j];

                    order[j] =
                            temp;
                }
            }
        }

        // Display results.
        resultArea.setText(
                "SEARCH RESULTS\n\n"
                + "Query: "
                + query
                + "\n"
                + "Type: "
                + type
                + "\n"
                + "Total Matches: "
                + positions.length
                + "\n\n"
                + "RANKED DOCUMENTS\n"
                + "============================\n\n"
        );

        int rank = 1;

        for (
                int i = 0;
                i < order.length;
                i++
        ) {

            int index =
                    order[i];

            if (
                    matchCount[index]
                    == 0
            ) {

                continue;
            }

            resultArea.append(
                    rank
                    + ". "
                    + documents[index]
                            .getName()
                    + "\n"
                    + "   Matches: "
                    + matchCount[index]
                    + "\n\n"
            );

            rank++;
        }

        resultArea.append(
                "MATCH POSITIONS\n"
                + "============================\n"
        );

        for (
                int i = 0;
                i < positions.length;
                i++
        ) {

            resultArea.append(
                    "Match "
                    + (i + 1)
                    + " -> position "
                    + positions[i]
                    + "\n"
            );
        }
    }

    /*
     * Prefix search.
     *
     * The query must occur at the beginning
     * of a document.
     */
    private void performPrefixSearch(
            String query) {

        resultArea.setText(
                "PREFIX SEARCH RESULTS\n\n"
        );

        int found = 0;

        for (
                int i = 0;
                i < documents.length;
                i++
        ) {

            String content =
                    documents[i]
                            .getContent()
                            .trim();

            if (
                    content.startsWith(query)
            ) {

                found++;

                resultArea.append(
                        found
                        + ". "
                        + documents[i]
                                .getName()
                        + "\n"
                        + "   Prefix matched\n\n"
                );
            }
        }

        if (found == 0) {

            resultArea.append(
                    "No document starts with:\n"
                    + query
            );
        }
    }

    public static void main(String[] args) {

        // Start the Swing application.
        SwingUtilities.invokeLater(
                () -> {

                    Main application =
                            new Main();

                    application.frame
                            .setVisible(true);
                }
        );
    }
}