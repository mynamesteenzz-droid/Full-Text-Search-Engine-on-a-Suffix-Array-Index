package FullTextSearchEngine;

public class SearchEngine {

    private String text;
    private int[] suffixArray;
    private int[] lcpArray;

    public SearchEngine(
            String text,
            int[] suffixArray,
            int[] lcpArray) {

        this.text = text;
        this.suffixArray = suffixArray;
        this.lcpArray = lcpArray;
    }

    /*
     * Main search operation.
     *
     * The suffix array keeps all suffixes in sorted order.
     * Therefore binary search can find the range of suffixes
     * beginning with the required query.
     */
    public int[] search(String query) {

        if (
                query == null ||
                query.length() == 0 ||
                text.length() == 0
        ) {

            return new int[0];
        }

        int first =
                findFirst(query);

        if (first == -1) {
            return new int[0];
        }

        int last =
                findLast(query);

        int count =
                last - first + 1;

        int[] positions =
                new int[count];

        // Every suffix between first and last
        // contains the query.
        for (int i = 0; i < count; i++) {

            positions[i] =
                    suffixArray[first + i];
        }

        return positions;
    }

    /*
     * Finds the first suffix beginning with query.
     */
    private int findFirst(String query) {

        int low = 0;
        int high =
                suffixArray.length - 1;

        int answer = -1;

        while (low <= high) {

            int mid =
                    low + (high - low) / 2;

            int comparison =
                    compareSuffixWithQuery(
                            suffixArray[mid],
                            query
                    );

            if (comparison >= 0) {

                if (comparison == 0) {
                    answer = mid;
                }

                high = mid - 1;

            } else {

                low = mid + 1;
            }
        }

        return answer;
    }

    /*
     * Finds the last suffix beginning with query.
     */
    private int findLast(String query) {

        int low = 0;
        int high =
                suffixArray.length - 1;

        int answer = -1;

        while (low <= high) {

            int mid =
                    low + (high - low) / 2;

            int comparison =
                    compareSuffixWithQuery(
                            suffixArray[mid],
                            query
                    );

            if (comparison <= 0) {

                if (comparison == 0) {
                    answer = mid;
                }

                low = mid + 1;

            } else {

                high = mid - 1;
            }
        }

        return answer;
    }

    /*
     * Compares one suffix with the query.
     *
     *  0  -> query is found at the beginning
     * -1  -> suffix comes before query
     *  1  -> suffix comes after query
     */
    private int compareSuffixWithQuery(
            int suffixStart,
            String query) {

        int i = suffixStart;
        int j = 0;

        while (
                i < text.length() &&
                j < query.length()
        ) {

            char a =
                    text.charAt(i);

            char b =
                    query.charAt(j);

            if (a < b) {
                return -1;
            }

            if (a > b) {
                return 1;
            }

            i++;
            j++;
        }

        if (j == query.length()) {
            return 0;
        }

        return -1;
    }

    /*
     * Counts how many times the query appears
     * inside a particular document.
     *
     * This is used for ranking.
     */
    public int countMatches(
            String documentContent,
            String query) {

        if (
                documentContent == null ||
                query == null ||
                query.length() == 0
        ) {

            return 0;
        }

        int count = 0;

        for (
                int start = 0;
                start <=
                documentContent.length()
                - query.length();
                start++
        ) {

            boolean match = true;

            for (
                    int j = 0;
                    j < query.length();
                    j++
            ) {

                if (
                        documentContent.charAt(
                                start + j
                        )
                        !=
                        query.charAt(j)
                ) {

                    match = false;
                    break;
                }
            }

            if (match) {
                count++;
            }
        }

        return count;
    }

    /*
     * Returns the number of query occurrences
     * for every document.
     */
    public int[] rankDocuments(
            Documents[] documents,
            String query) {

        int[] ranking =
                new int[documents.length];

        for (int i = 0;
             i < documents.length;
             i++) {

            ranking[i] =
                    countMatches(
                            documents[i].getContent(),
                            query
                    );
        }

        return ranking;
    }

    /*
     * This method uses the LCP information to
     * reuse already-known matching characters
     * during binary search.
     *
     * It demonstrates the LCP-accelerated search
     * concept used by the project.
     */
    public int lcpAcceleratedSearch(
            String query) {

        if (
                query == null ||
                query.length() == 0
        ) {

            return -1;
        }

        int low = 0;
        int high =
                suffixArray.length - 1;

        int lowLCP = 0;
        int highLCP = 0;

        while (low <= high) {

            int mid =
                    low + (high - low) / 2;

            int known =
                    Math.min(
                            lowLCP,
                            highLCP
                    );

            int matched =
                    compareFromLCP(
                            suffixArray[mid],
                            query,
                            known
                    );

            if (
                    matched ==
                    query.length()
            ) {

                return suffixArray[mid];
            }

            if (
                    suffixArray[mid]
                    + matched
                    >= text.length()
            ) {

                return -1;
            }

            char suffixCharacter =
                    text.charAt(
                            suffixArray[mid]
                            + matched
                    );

            char queryCharacter =
                    query.charAt(matched);

            if (
                    suffixCharacter
                    < queryCharacter
            ) {

                low = mid + 1;
                lowLCP = matched;

            } else {

                high = mid - 1;
                highLCP = matched;
            }
        }

        return -1;
    }

    private int compareFromLCP(
            int suffixStart,
            String query,
            int knownMatch) {

        int matched =
                knownMatch;

        while (
                matched < query.length() &&
                suffixStart + matched
                < text.length()
        ) {

            if (
                    text.charAt(
                            suffixStart + matched
                    )
                    !=
                    query.charAt(matched)
            ) {

                break;
            }

            matched++;
        }

        return matched;
    }
}