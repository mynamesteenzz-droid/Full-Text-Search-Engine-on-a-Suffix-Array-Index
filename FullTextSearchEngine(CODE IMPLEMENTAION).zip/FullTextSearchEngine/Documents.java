package FullTextSearchEngine;

public class Documents {

    // Stores the document file name.
    private String name;

    // Stores the complete document content.
    private String content;

    public Documents(
            String name,
            String content) {

        this.name = name;
        this.content = content;
    }

    public String getName() {
        return name;
    }

    public String getContent() {
        return content;
    }
}